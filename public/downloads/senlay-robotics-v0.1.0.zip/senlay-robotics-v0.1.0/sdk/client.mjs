import fs from 'node:fs';

const DEFAULT_TIMEOUT_MS = 15_000;
const MAX_TIMEOUT_MS = 30_000;
const CAPABILITY_SCHEMA_VERSION = '1';
const PROVIDER_CAPABILITY_SCHEMA = JSON.parse(fs.readFileSync(
  new URL('./schemas/provider-capability-v1.schema.json', import.meta.url),
  'utf8'
));

export class SenlayRequestError extends Error {
  constructor(message, status = null, retryAfterMs = null) {
    super(message);
    this.name = 'SenlayRequestError';
    this.status = status;
    this.retryAfterMs = retryAfterMs;
  }
}

function isLoopback(hostname) {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host === '::1') return true;
  if (!/^127(?:\.\d{1,3}){3}$/.test(host)) return false;
  return host.split('.').every((part, index) => index === 0 || Number(part) <= 255);
}

function normalizeBaseUrl(value) {
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new TypeError('baseUrl must be an absolute HTTP(S) URL.');
  }
  if (url.username || url.password || url.search || url.hash) {
    throw new TypeError('baseUrl cannot contain credentials, query parameters, or a fragment.');
  }
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && isLoopback(url.hostname))) {
    throw new TypeError('baseUrl must use HTTPS; HTTP is allowed only for loopback development.');
  }
  return url.toString().replace(/\/+$/, '');
}

function timeoutValue(value) {
  const timeout = Number(value ?? DEFAULT_TIMEOUT_MS);
  if (!Number.isFinite(timeout) || timeout <= 0) throw new TypeError('timeoutMs must be a positive finite number.');
  return Math.min(Math.max(1, Math.floor(timeout)), MAX_TIMEOUT_MS);
}

function isDateTime(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(Z|([+-])(\d{2}):(\d{2}))$/.exec(value);
  if (!match) return false;
  const [, yearText, monthText, dayText, hourText, minuteText, secondText, zone, , offsetHourText, offsetMinuteText] = match;
  const year = Number(yearText);
  const month = Number(monthText);
  const day = Number(dayText);
  const leapYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const monthDays = [31, leapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (year < 1 || month < 1 || month > 12 || day < 1 || day > monthDays[month - 1]
    || Number(hourText) > 23 || Number(minuteText) > 59 || Number(secondText) > 59) return false;
  if (zone !== 'Z' && (Number(offsetHourText) > 23 || Number(offsetMinuteText) > 59)) return false;
  return Number.isFinite(Date.parse(value));
}

function matchesSchema(value, schema, rootSchema = PROVIDER_CAPABILITY_SCHEMA, depth = 0) {
  if (depth > 32) return false;
  if (schema.$ref) {
    const ref = schema.$ref;
    if (!ref.startsWith('#/')) return false;
    const target = ref.slice(2).split('/').map(part => part.replace(/~1/g, '/').replace(/~0/g, '~'))
      .reduce((current, key) => current?.[key], rootSchema);
    return Boolean(target && matchesSchema(value, target, rootSchema, depth + 1));
  }
  if (schema.anyOf && !schema.anyOf.some(option => matchesSchema(value, option, rootSchema, depth + 1))) return false;
  if (schema.const !== undefined && value !== schema.const) return false;
  if (schema.enum && !schema.enum.includes(value)) return false;

  const types = Array.isArray(schema.type) ? schema.type : schema.type ? [schema.type] : [];
  if (types.length && !types.some(type => {
    if (type === 'null') return value === null;
    if (type === 'object') return value !== null && typeof value === 'object' && !Array.isArray(value);
    if (type === 'array') return Array.isArray(value);
    if (type === 'integer') return Number.isInteger(value);
    if (type === 'number') return typeof value === 'number' && Number.isFinite(value);
    return typeof value === type;
  })) return false;

  if (typeof value === 'string') {
    if (schema.minLength != null && value.length < schema.minLength) return false;
    if (schema.format === 'date-time' && !isDateTime(value)) return false;
  }
  if (typeof value === 'number' && schema.minimum != null && value < schema.minimum) return false;
  if (Array.isArray(value) && schema.items && !value.every(item => matchesSchema(item, schema.items, rootSchema, depth + 1))) return false;
  if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
    if ((schema.required || []).some(key => !Object.hasOwn(value, key))) return false;
    for (const [key, child] of Object.entries(value)) {
      if (schema.properties?.[key]) {
        if (!matchesSchema(child, schema.properties[key], rootSchema, depth + 1)) return false;
      } else if (schema.additionalProperties === false) {
        return false;
      } else if (schema.additionalProperties && typeof schema.additionalProperties === 'object'
        && !matchesSchema(child, schema.additionalProperties, rootSchema, depth + 1)) {
        return false;
      }
    }
  }
  return true;
}

function isProviderCapabilityV1(value) {
  return matchesSchema(value, PROVIDER_CAPABILITY_SCHEMA.$defs.providerCapability);
}

export function createSenlayClient({ baseUrl, apiKey, fetchImpl = globalThis.fetch, timeoutMs = DEFAULT_TIMEOUT_MS, strictCapabilities = false } = {}) {
  const normalizedBaseUrl = normalizeBaseUrl(baseUrl);
  if (typeof apiKey !== 'string' || !apiKey.trim()) throw new TypeError('apiKey is required.');
  if (typeof fetchImpl !== 'function') throw new TypeError('fetchImpl must be a function.');
  const boundedTimeoutMs = timeoutValue(timeoutMs);

  async function getPWM({ lat, lng, field = 'general', view = 'compact', profile, signal } = {}) {
    if (typeof lat !== 'number' || !Number.isFinite(lat) || lat < -90 || lat > 90) throw new TypeError('lat must be a finite latitude.');
    if (typeof lng !== 'number' || !Number.isFinite(lng) || lng < -180 || lng > 180) throw new TypeError('lng must be a finite longitude.');
    if (profile !== undefined && !['wind', 'full'].includes(profile)) throw new TypeError('profile must be wind or full.');
    if (signal?.aborted) throw new SenlayRequestError('Request aborted by caller.');

    const url = new URL(`${normalizedBaseUrl}/api/v1/pwm`);
    url.searchParams.set('lat', String(lat));
    url.searchParams.set('lng', String(lng));
    url.searchParams.set('field', String(field));
    url.searchParams.set('view', String(view));
    if (profile !== undefined) url.searchParams.set('profile', profile);

    const controller = new AbortController();
    let timedOut = false;
    const abortFromCaller = () => controller.abort();
    signal?.addEventListener('abort', abortFromCaller, { once: true });
    const timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, boundedTimeoutMs);

    try {
      const response = await fetchImpl(url, {
        method: 'GET',
        headers: { Authorization: `Bearer ${apiKey}`, Accept: 'application/json' },
        signal: controller.signal,
        redirect: 'error'
      });
      if (!response || !response.ok) {
        const status = Number.isInteger(response?.status) ? response.status : null;
        const retryHeader = response?.headers?.get?.('retry-after');
        const retrySeconds = retryHeader && /^\d+$/.test(retryHeader) ? Number(retryHeader) : null;
        const retryDate = retryHeader && retrySeconds === null ? Date.parse(retryHeader) : NaN;
        const retryAfterMs = retrySeconds !== null ? Math.min(1_800_000, retrySeconds * 1000)
          : Number.isFinite(retryDate) ? Math.max(0, Math.min(1_800_000, retryDate - Date.now())) : null;
        throw new SenlayRequestError(status ? `Senlay request failed (${status}).` : 'Senlay request failed.', status, retryAfterMs);
      }
      let body;
      try {
        body = await response.json();
      } catch {
        throw new SenlayRequestError('Senlay returned invalid JSON.');
      }
      if (timedOut) throw new SenlayRequestError('Senlay request timed out.');
      if (signal?.aborted) throw new SenlayRequestError('Request aborted by caller.');
      if (!body || typeof body !== 'object' || Array.isArray(body)) throw new SenlayRequestError('Senlay returned an invalid response object.');
      const capabilities = Array.isArray(body?.provider_capabilities) ? body.provider_capabilities : null;
      const versions = capabilities?.map(item => item?.schema_version).filter(value => value != null) || [];
      const capabilityVersion = versions.length && versions.every(value => value === versions[0]) ? versions[0] : null;
      const compatible = Boolean(capabilities?.length && capabilities.every(item => item?.schema_version === CAPABILITY_SCHEMA_VERSION && isProviderCapabilityV1(item)));
      if (strictCapabilities && !compatible) throw new SenlayRequestError('Senlay provider capabilities are unavailable or use an unsupported schema version.');
      return {
        response: body,
        capabilities,
        compatibility: {
          capabilitiesAvailable: Boolean(capabilities),
          capabilitySchemaVersion: capabilityVersion,
          capabilitiesCompatible: compatible,
          status: !capabilities ? 'unavailable' : compatible ? 'compatible' : 'unknown_version_or_shape'
        }
      };
    } catch (error) {
      if (error instanceof SenlayRequestError) throw error;
      if (timedOut) throw new SenlayRequestError('Senlay request timed out.');
      if (signal?.aborted) throw new SenlayRequestError('Request aborted by caller.');
      throw new SenlayRequestError('Senlay network request failed.');
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', abortFromCaller);
    }
  }

  return Object.freeze({ getPWM });
}

export const _test = Object.freeze({ normalizeBaseUrl, timeoutValue, isLoopback });
