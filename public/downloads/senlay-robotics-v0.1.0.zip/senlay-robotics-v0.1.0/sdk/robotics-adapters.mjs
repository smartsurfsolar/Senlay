// Senlay robotics example. MIT license applies when distributed with examples/robotics/LICENSE.
import dgram from 'node:dgram';
import { isIP } from 'node:net';

const MESSAGES = new Map([[24, { crc: 24, base: 30, full: 52 }], [33, { crc: 104, base: 28, full: 28 }]]);
const MAX_MESSAGE_BYTES = 1_048_576;
export const DEFAULT_ENVIRONMENT_INTERVAL_MS = 120_000;

function toDate(value) {
  const date = new Date(value instanceof Date ? value.getTime() : value ?? Date.now());
  if (!Number.isFinite(date.getTime())) throw new TypeError('receivedAt must be a valid date.');
  return date;
}
function validCoordinates(lat, lng) {
  return typeof lat === 'number' && Number.isFinite(lat) && lat >= -90 && lat <= 90
    && typeof lng === 'number' && Number.isFinite(lng) && lng >= -180 && lng <= 180;
}
function accumulate(crc, byte) {
  let t = byte ^ (crc & 255); t ^= (t << 4) & 255;
  return ((crc >> 8) ^ (t << 8) ^ (t << 3) ^ (t >> 4)) & 65535;
}
function checksum(packet, start, end, extra) {
  let crc = 65535;
  for (let i = start; i < end; i += 1) crc = accumulate(crc, packet[i]);
  return accumulate(crc, extra);
}
function mavTime(value, unit) {
  const raw = String(value);
  const epoch = unit === 'us' && value >= 100_000_000_000_000n && value <= 8_640_000_000_000_000_000n;
  return { raw, unit, clockBasis: epoch ? 'unix_reported' : 'boot_relative_or_unknown', observedAt: epoch ? new Date(Number(value / 1000n)).toISOString() : null, verified: false };
}
function decodeMavlink(id, payload, receivedAt, identity, wireLength) {
  const common = { source: 'mavlink_udp', mode: 'live_telemetry', receivedAt: toDate(receivedAt).toISOString(), sourceIdentity: identity };
  if (id === 24) {
    const fixType = payload[28];
    const lat = payload.readInt32LE(8) / 1e7, lng = payload.readInt32LE(12) / 1e7;
    const hasFix = fixType >= 2 && fixType <= 8;
    const hAcc = payload.readUInt32LE(34);
    // eph is dimensionless HDOP *100. h_acc is a MAVLink 2 extension in mm.
    // A zero/omitted extension is unknown; it cannot establish perfect accuracy.
    const position = hasFix && validCoordinates(lat, lng) ? {
      lat, lng, hdop: payload.readUInt16LE(20) === 65535 ? null : payload.readUInt16LE(20) / 100,
      horizontalAccuracyM: wireLength > 34 && hAcc > 0 ? hAcc / 1000 : null,
      accuracyBasis: wireLength > 34 && hAcc > 0 ? 'mavlink_h_acc' : 'unknown',
      coordinateQuality: fixType >= 3 ? '3d_fix' : '2d_fix'
    } : null;
    return { ...common, messageType: 'GPS_RAW_INT', sourceTime: mavTime(payload.readBigUInt64LE(0), 'us'), position, positionStatus: position ? 'available' : hasFix ? 'invalid_coordinates' : 'no_fix', fixType };
  }
  const lat = payload.readInt32LE(4) / 1e7, lng = payload.readInt32LE(8) / 1e7;
  const position = validCoordinates(lat, lng) ? { lat, lng, hdop: null, horizontalAccuracyM: null, accuracyBasis: 'unknown', coordinateQuality: 'unknown' } : null;
  return { ...common, messageType: 'GLOBAL_POSITION_INT', sourceTime: mavTime(BigInt(payload.readUInt32LE(0)), 'ms'), position, positionStatus: position ? 'available' : 'invalid_coordinates' };
}

/** Decode CRC-checked common MAVLink position messages. CRC/signature presence is not sender authentication. */
export function parseMavlinkDatagram(datagram, receivedAt = new Date()) {
  if (!Buffer.isBuffer(datagram) && !(datagram instanceof Uint8Array)) throw new TypeError('datagram must be bytes.');
  const packet = Buffer.from(datagram), events = [];
  let cursor = 0;
  while (cursor < packet.length) {
    if (![254, 253].includes(packet[cursor])) { cursor += 1; continue; }
    const v2 = packet[cursor] === 253, header = v2 ? 10 : 6;
    if (packet.length - cursor < header) break;
    const length = packet[cursor + 1], flags = v2 ? packet[cursor + 2] : 0;
    if (flags & ~1) { cursor += 1; continue; }
    const size = header + length + 2 + ((flags & 1) ? 13 : 0);
    if (packet.length - cursor < size) { cursor += 1; continue; }
    const id = v2 ? packet[cursor + 7] | packet[cursor + 8] << 8 | packet[cursor + 9] << 16 : packet[cursor + 5];
    const def = MESSAGES.get(id), end = cursor + header + length;
    if (def && length >= (v2 ? 1 : def.base) && length <= (v2 ? def.full : def.base)
      && packet.readUInt16LE(end) === checksum(packet, cursor + 1, end, def.crc)) {
      // MAVLink 2 strips trailing zeros, including bytes inside base scalar fields.
      const payload = Buffer.alloc(def.full);
      packet.copy(payload, 0, cursor + header, end);
      const identity = { systemId: packet[cursor + (v2 ? 5 : 3)], componentId: packet[cursor + (v2 ? 6 : 4)], sequence: packet[cursor + (v2 ? 4 : 2)], protocol: v2 ? 2 : 1, signaturePresent: Boolean(flags & 1), authenticated: false };
      events.push(decodeMavlink(id, payload, receivedAt, identity, length));
    }
    cursor += size;
  }
  return events;
}

function rosText(data) {
  if (typeof data === 'string') return data;
  if (Buffer.isBuffer(data)) return data.toString('utf8');
  if (data instanceof ArrayBuffer) return Buffer.from(data).toString('utf8');
  if (ArrayBuffer.isView(data)) return Buffer.from(data.buffer, data.byteOffset, data.byteLength).toString('utf8');
  return null;
}
function rosSourceTime(stamp, clock) {
  const sec = stamp?.sec ?? stamp?.secs, ns = stamp?.nanosec ?? stamp?.nsecs;
  const valid = Number.isSafeInteger(sec) && sec >= 0 && Number.isInteger(ns) && ns >= 0 && ns < 1e9;
  const ms = valid ? sec * 1000 + ns / 1e6 : NaN;
  const unix = clock === 'unix' && Number.isFinite(ms) && ms > 0 && ms <= 8.64e15;
  return { raw: valid ? { sec, nanosec: ns } : null, unit: 'ros_stamp', clockBasis: unix ? 'unix_operator_declared' : 'ros_clock_unknown', observedAt: unix ? new Date(ms).toISOString() : null, verified: false };
}
function rosUncertainty(msg) {
  const type = msg.position_covariance_type;
  const matrix = msg.position_covariance;
  const valid = [1, 2, 3].includes(type) && Array.isArray(matrix) && matrix.length === 9 && matrix.every(Number.isFinite)
    && [0, 4, 8].every(i => matrix[i] >= 0)
    && Math.abs(matrix[1] - matrix[3]) < 1e-8 && Math.abs(matrix[2] - matrix[6]) < 1e-8 && Math.abs(matrix[5] - matrix[7]) < 1e-8
    && matrix[0] * matrix[4] >= matrix[1] * matrix[1] - 1e-8
    && matrix[0] * matrix[8] >= matrix[2] * matrix[2] - 1e-8
    && matrix[4] * matrix[8] >= matrix[5] * matrix[5] - 1e-8
    && matrix[0] * (matrix[4] * matrix[8] - matrix[5] * matrix[7])
      - matrix[1] * (matrix[3] * matrix[8] - matrix[5] * matrix[6])
      + matrix[2] * (matrix[3] * matrix[7] - matrix[4] * matrix[6]) >= -1e-8;
  // Retain ENU matrix and explicitly named axis sigmas; do not invent a radial accuracy.
  return { horizontalAccuracyM: null, accuracyBasis: valid ? 'ros_enu_covariance' : 'unknown', covarianceType: [0, 1, 2, 3].includes(type) ? type : null, covarianceEnuM2: valid ? [...matrix] : null, eastSigmaM: valid ? Math.sqrt(matrix[0]) : null, northSigmaM: valid ? Math.sqrt(matrix[4]) : null, upSigmaM: valid ? Math.sqrt(matrix[8]) : null };
}
/** Parse geodetic NavSatFix; ROS time is unknown unless the operator declares a Unix clock. */
export function parseRosbridgeMessage(data, receivedAt = new Date(), { topic: expectedTopic, rosClock = 'unknown' } = {}) {
  const raw = rosText(data);
  if (!raw || Buffer.byteLength(raw) > MAX_MESSAGE_BYTES) return null;
  let packet;
  try { packet = JSON.parse(raw); } catch { return null; }
  if (!packet || packet.op !== 'publish' || !packet.msg || typeof packet.msg !== 'object' || (expectedTopic && packet.topic !== expectedTopic)) return null;
  const msg = packet.msg, status = msg.status?.status;
  const hasFix = Number.isInteger(status) && status >= 0 && status <= 2;
  const position = hasFix && validCoordinates(msg.latitude, msg.longitude) ? { lat: msg.latitude, lng: msg.longitude, coordinateQuality: 'gnss_fix_reported', hdop: null, ...rosUncertainty(msg) } : null;
  return { source: 'rosbridge', mode: 'live_telemetry', messageType: packet.type || 'sensor_msgs/msg/NavSatFix', receivedAt: toDate(receivedAt).toISOString(), sourceTime: rosSourceTime(msg.header?.stamp, rosClock), position, positionStatus: position ? 'available' : !hasFix ? 'no_fix_or_unknown_status' : 'invalid_coordinates', sourceIdentity: { topic: packet.topic || null, frameId: typeof msg.header?.frame_id === 'string' ? msg.header.frame_id : null, authenticated: false } };
}

function dispatch(callback, telemetry, onError) {
  try { Promise.resolve(callback(telemetry)).catch(() => onError?.(new Error('Telemetry callback failed.'))); }
  catch { onError?.(new Error('Telemetry callback failed.')); }
}
/** A receive-only UDP listener. Scope the network and select one robot upstream. */
export function createMavlinkUdpAdapter({ bindAddress = '127.0.0.1', port = 14550, systemId, componentId, onTelemetry, onError, onState, socketFactory = dgram.createSocket } = {}) {
  if (typeof onTelemetry !== 'function') throw new TypeError('onTelemetry callback is required.');
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new TypeError('port must be from 1 to 65535.');
  if (isIP(bindAddress) === 0) throw new TypeError('bindAddress must be an IP address.');
  for (const value of [systemId, componentId]) if (value !== undefined && (!Number.isInteger(value) || value < 1 || value > 255)) throw new TypeError('MAVLink identity filters must be from 1 to 255.');
  const socket = socketFactory(isIP(bindAddress) === 6 ? 'udp6' : 'udp4');
  let closed = false;
  socket.on('error', () => { onState?.({ status: 'transport_error', transport: 'mavlink_udp' }); onError?.(new Error('MAVLink UDP listener error.')); });
  socket.on('listening', () => onState?.({ status: 'listening', transport: 'mavlink_udp' }));
  socket.on('message', packet => {
    const events = parseMavlinkDatagram(packet, new Date());
    if (!events.length) onState?.({ status: 'telemetry_ignored', reason: 'unsupported_or_invalid_frame' });
    for (const telemetry of events) {
      if ((systemId !== undefined && telemetry.sourceIdentity.systemId !== systemId) || (componentId !== undefined && telemetry.sourceIdentity.componentId !== componentId)) continue;
      dispatch(onTelemetry, telemetry, onError);
    }
  });
  socket.bind(port, bindAddress);
  return Object.freeze({ close() { if (!closed) { closed = true; socket.close(); onState?.({ status: 'closed', transport: 'mavlink_udp' }); } } });
}
function rosUrl(value) {
  let url;
  try { url = new URL(value); } catch { throw new TypeError('rosbridgeUrl must be an absolute ws:// or wss:// URL.'); }
  if (!['ws:', 'wss:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw new TypeError('rosbridgeUrl must use ws:// or wss:// without credentials, query parameters, or a fragment.');
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  const loopback = ['localhost', '::1'].includes(host) || (isIP(host) === 4 && host.startsWith('127.'));
  if (url.protocol === 'ws:' && !loopback) throw new TypeError('Remote rosbridge connections must use wss://.');
  return url.toString();
}
/** Read-only rosbridge subscription with bounded reconnect; never publishes robot commands. */
export function createRosbridgeAdapter({ rosbridgeUrl, topic = '/fix', messageType = 'sensor_msgs/msg/NavSatFix', rosClock = 'unknown', onTelemetry, onError, onState, WebSocketImpl = globalThis.WebSocket, setTimeoutFn = setTimeout, clearTimeoutFn = clearTimeout } = {}) {
  const url = rosUrl(rosbridgeUrl);
  if (typeof onTelemetry !== 'function') throw new TypeError('onTelemetry callback is required.');
  if (typeof topic !== 'string' || !/^\/[A-Za-z0-9_/]{1,254}$/.test(topic)) throw new TypeError('topic must be a valid absolute ROS topic.');
  if (typeof messageType !== 'string' || !/^[A-Za-z][A-Za-z0-9_]*(?:\/[A-Za-z][A-Za-z0-9_]*){1,2}$/.test(messageType)) throw new TypeError('messageType is invalid.');
  if (!['unknown', 'unix'].includes(rosClock)) throw new TypeError('rosClock must be unknown or unix.');
  if (typeof WebSocketImpl !== 'function') throw new TypeError('WebSocket requires Node.js 22.');
  let socket, timer, closed = false, attempts = 0;
  function reconnect() {
    if (closed || timer) return;
    const retryAfterMs = Math.min(30_000, 1000 * 2 ** Math.min(attempts++, 5));
    onState?.({ status: 'disconnected', transport: 'rosbridge', retryAfterMs });
    timer = setTimeoutFn(() => { timer = null; connect(); }, retryAfterMs);
  }
  function connect() {
    if (closed) return;
    onState?.({ status: 'connecting', transport: 'rosbridge' });
    try { socket = new WebSocketImpl(url); } catch { onError?.(new Error('ROS bridge connection error.')); reconnect(); return; }
    const current = socket;
    current.addEventListener('open', () => {
      if (closed || socket !== current) return;
      attempts = 0;
      current.send(JSON.stringify({ op: 'subscribe', topic, type: messageType, throttle_rate: 1000, queue_length: 1 }));
      onState?.({ status: 'subscribed', transport: 'rosbridge', topic });
    });
    current.addEventListener('error', () => { onState?.({ status: 'transport_error', transport: 'rosbridge' }); onError?.(new Error('ROS bridge connection error.')); });
    current.addEventListener('close', () => { if (socket === current) reconnect(); });
    current.addEventListener('message', event => {
      if (closed || socket !== current) return;
      const telemetry = parseRosbridgeMessage(event?.data, new Date(), { topic, rosClock });
      if (telemetry) dispatch(onTelemetry, telemetry, onError);
      else onState?.({ status: 'telemetry_ignored', reason: 'invalid_or_other_topic' });
    });
  }
  connect();
  return Object.freeze({ close() { closed = true; if (timer) clearTimeoutFn(timer); timer = null; socket?.close(); onState?.({ status: 'closed', transport: 'rosbridge' }); } });
}

function freshness(telemetry, now, maxAge) {
  const ageMs = now - Date.parse(telemetry.receivedAt);
  const observed = Date.parse(telemetry.sourceTime?.observedAt);
  const measurementAge = Number.isFinite(observed) ? now - observed : null;
  return {
    receiveFreshness: { status: !Number.isFinite(ageMs) ? 'unknown' : ageMs < 0 ? 'future_timestamp' : ageMs > maxAge ? 'stale' : 'fresh', ageMs: Number.isFinite(ageMs) ? ageMs : null, basis: 'local_receive_time' },
    measurementFreshness: { status: measurementAge === null ? 'unknown' : measurementAge < -5000 ? 'future_timestamp' : measurementAge > maxAge ? 'stale' : 'fresh_reported_time', ageMs: measurementAge, basis: telemetry.sourceTime?.clockBasis || 'unknown', verified: false }
  };
}
/** Slow environmental polling; single in-flight request, capacity-aware cadence, and error backoff. */
export function createRoboticsContextAdapter({ client, field = 'drone', profile = field === 'drone' ? 'wind' : 'full', maxTelemetryAgeMs = 15_000, minRequestIntervalMs = DEFAULT_ENVIRONMENT_INTERVAL_MS, now = Date.now, onState } = {}) {
  if (!client || typeof client.getPWM !== 'function') throw new TypeError('client.getPWM is required.');
  if (typeof field !== 'string' || !field.trim()) throw new TypeError('field must be a non-empty string.');
  if (!['wind', 'full'].includes(profile)) throw new TypeError('profile must be wind or full.');
  if (!Number.isFinite(maxTelemetryAgeMs) || maxTelemetryAgeMs < 1) throw new TypeError('maxTelemetryAgeMs must be positive.');
  if (!Number.isFinite(minRequestIntervalMs) || minRequestIntervalMs < 0) throw new TypeError('minRequestIntervalMs must be zero or positive.');
  if (typeof now !== 'function') throw new TypeError('now must be a function.');
  let lastRequestAt = null, retryAt = 0, inFlight = false, failures = 0, sequence = 0;
  const emit = value => { onState?.(value); return value; };
  async function handleTelemetry(telemetry) {
    const current = Number(now());
    if (!Number.isFinite(current)) throw new TypeError('now() must return a finite timestamp.');
    if (!validCoordinates(telemetry?.position?.lat, telemetry?.position?.lng)) return emit({ status: 'skipped', reason: 'valid_position_unavailable' });
    if (telemetry.positionStatus && telemetry.positionStatus !== 'available') return emit({ status: 'skipped', reason: 'position_status_unavailable' });
    const before = freshness(telemetry, current, maxTelemetryAgeMs);
    if (before.receiveFreshness.status !== 'fresh') return emit({ status: 'skipped', reason: before.receiveFreshness.status === 'stale' ? 'stale_telemetry' : 'invalid_or_future_receive_time', ...before });
    if (['stale', 'future_timestamp'].includes(before.measurementFreshness.status)) return emit({ status: 'skipped', reason: 'stale_or_future_measurement', ...before });
    if (inFlight) return emit({ status: 'skipped', reason: 'lookup_in_flight' });
    if (current < retryAt) return emit({ status: 'skipped', reason: 'request_backoff', retryAfterMs: retryAt - current });
    if (lastRequestAt !== null && current - lastRequestAt < minRequestIntervalMs) return emit({ status: 'skipped', reason: 'request_interval', retryAfterMs: minRequestIntervalMs - (current - lastRequestAt) });
    const seq = ++sequence, requestStartedAt = new Date(current).toISOString();
    // Snapshot metadata before awaiting so callers cannot mutate the query/result identity.
    const snapshot = structuredClone(telemetry);
    lastRequestAt = current; inFlight = true;
    emit({ status: 'lookup_started', sequence: seq, requestStartedAt });
    try {
      const result = await client.getPWM({ lat: snapshot.position.lat, lng: snapshot.position.lng, field, view: 'full', profile });
      const completed = Number(now()), after = freshness(snapshot, completed, maxTelemetryAgeMs);
      failures = 0; retryAt = 0;
      return emit({ status: after.receiveFreshness.status === 'fresh' && !['stale', 'future_timestamp'].includes(after.measurementFreshness.status) ? 'context' : 'stale_context', mode: snapshot.mode || 'live_telemetry', sequence: seq, requestStartedAt, requestCompletedAt: new Date(completed).toISOString(), elapsedMs: Math.max(0, completed - current), telemetry: { ...snapshot, ...after }, environment: result?.response ?? result, capabilityCompatibility: result?.compatibility || null, safetyClearance: 'not_provided', note: 'Environmental context only. This result does not clear or control a robot.' });
    } catch (error) {
      failures += 1;
      const retryAfterMs = Math.min(1_800_000, Math.max(minRequestIntervalMs, 1000) * 2 ** Math.min(failures - 1, 10));
      const serverDelay = Number.isFinite(error?.retryAfterMs) ? Math.min(1_800_000, Math.max(0, error.retryAfterMs)) : 0;
      retryAt = Number(now()) + Math.max(retryAfterMs, serverDelay);
      return emit({ status: 'request_error', message: 'Environmental lookup failed; inspect connection, key, quota, and provider status.', httpStatus: Number.isInteger(error?.status) ? error.status : null, retryAfterMs: Math.max(retryAfterMs, serverDelay), sequence: seq });
    } finally { inFlight = false; }
  }
  return Object.freeze({ handleTelemetry, getState: () => ({ inFlight, retryAt, lastRequestAt, minRequestIntervalMs }) });
}
