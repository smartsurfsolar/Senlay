# MAVLink reference fixtures

`mavlink-reference.json` contains bytes emitted by the real generated MAVLink C
packing/finalization functions, independently of Senlay's JavaScript parser.
The generator is Senlay's `reference-generator.c`. Upstream headers are not
included in this example distribution.

Reference: https://github.com/mavlink/c_library_v2/tree/a2d0ecf011a4aaa7840480e43f4e38d8c9e79d29

To regenerate in a temporary directory, retrieve exactly the eight headers
listed in `headersSha256` from that revision, preserving their relative paths,
and verify the recorded SHA-256 digests. Copy `reference-generator.c` alongside
`protocol.h`, then run:

```bash
gcc -std=c99 -o reference-generator reference-generator.c -lm
./reference-generator
```

The resulting named hex packets must equal `packets` in the JSON file. Node
runtime/tests use the frozen JSON and need neither GCC nor external downloads.
Fixture coverage includes MAVLink 1 HDOP, 12-byte and one-byte truncated MAVLink 2
GLOBAL_POSITION_INT, truncated GPS_RAW_INT with boot time/unknown EPH, and an
h_acc extension truncated within its uint32 high zero bytes. These are synthetic
protocol fixtures, not observations from a real robot.
