#define MAVLINK_STX 253
#define MAVLINK_LITTLE_ENDIAN 1
#define MAVLINK_ENDIAN MAVLINK_LITTLE_ENDIAN
#define MAVLINK_ALIGNED_FIELDS 1
#define MAVLINK_CRC_EXTRA 1
#define MAVLINK_COMMAND_24BIT 1
#define MAVLINK_MESSAGE_CRCS {{24,24,30,52,0,0,0},{33,104,28,28,0,0,0}}
#include "protocol.h"
#include "common/mavlink_msg_gps_raw_int.h"
#include "standard/mavlink_msg_global_position_int.h"
void emit(char *name,mavlink_message_t *msg){uint8_t b[512];int n=mavlink_msg_to_send_buffer(b,msg);printf("%s ",name);for(int i=0;i<n;i++)printf("%02x",b[i]);puts("");}
int main(){mavlink_message_t m; mavlink_status_t *s=mavlink_get_channel_status(0);
s->flags=MAVLINK_STATUS_FLAG_OUT_MAVLINK1;
mavlink_msg_gps_raw_int_pack(42,17,&m,1793448000000000ULL,3,10000000,20000000,123400,250,350,0,0,12,0,0,0,0,0,0);emit("gps_v1_hdop",&m);
s->flags=0;
mavlink_msg_global_position_int_pack(42,17,&m,1000,10000000,20000000,0,0,0,0,0,0);emit("global_v2_truncated",&m);
mavlink_msg_gps_raw_int_pack(42,17,&m,1793448000000000ULL,3,10000000,20000000,123400,250,350,0,0,12,0,4000,0,0,0,0);emit("gps_v2_hacc",&m);
mavlink_msg_gps_raw_int_pack(42,17,&m,123456ULL,3,10000000,20000000,123400,65535,65535,0,0,0,0,0,0,0,0,0);emit("gps_v2_boot_truncated",&m);
mavlink_msg_global_position_int_pack(42,17,&m,0,0,0,0,0,0,0,0,0);emit("global_v2_one_byte",&m);
return 0;}
