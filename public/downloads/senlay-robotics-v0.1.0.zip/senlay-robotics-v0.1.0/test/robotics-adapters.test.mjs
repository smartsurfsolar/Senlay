import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';
import { createSenlayClient } from '../sdk/client.mjs';
import { DEFAULT_ENVIRONMENT_INTERVAL_MS, createMavlinkUdpAdapter, createRosbridgeAdapter, createRoboticsContextAdapter, parseMavlinkDatagram, parseRosbridgeMessage } from '../sdk/robotics-adapters.mjs';

const reference = JSON.parse(fs.readFileSync(new URL('../sdk/fixtures/mavlink-reference.json', import.meta.url)));
const time = Date.parse(reference.referenceTime);
const frame = name => Buffer.from(reference.packets[name], 'hex');
function ros(overrides = {}) {
  return JSON.stringify({ op: 'publish', topic: '/fix', type: 'sensor_msgs/msg/NavSatFix', msg: { header: { stamp: { sec: time / 1000, nanosec: 0 }, frame_id: 'gps' }, status: { status: 0 }, latitude: 1, longitude: 2, position_covariance_type: 0, position_covariance: Array(9).fill(0), ...overrides } });
}
function telemetry(at = time) { return parseRosbridgeMessage(ros(), new Date(at)); }

test('reference C-generated MAVLink v1 HDOP is unitless, absent accuracy stays unknown', () => {
  const [value] = parseMavlinkDatagram(frame('gps_v1_hdop'), new Date(time));
  assert.equal(value.position.hdop, 2.5);
  assert.equal(value.position.horizontalAccuracyM, null);
  assert.equal(value.position.accuracyBasis, 'unknown');
  assert.equal(value.sourceTime.observedAt, reference.referenceTime);
  assert.equal(value.sourceIdentity.systemId, 42);
  assert.equal(value.sourceIdentity.authenticated, false);
});
test('reference C-generated v2 h_acc extension uses mm independently of HDOP and truncated scalar bytes', () => {
  const packet = frame('gps_v2_hacc');
  assert.equal(packet[1], 36); // h_acc high zero bytes removed by upstream C serializer.
  const [value] = parseMavlinkDatagram(packet, new Date(time));
  assert.equal(value.position.hdop, 2.5);
  assert.equal(value.position.horizontalAccuracyM, 4);
  assert.equal(value.position.accuracyBasis, 'mavlink_h_acc');
});
test('reference valid v2 truncation supports 12-byte and one-byte logical base payloads', () => {
  const [value] = parseMavlinkDatagram(frame('global_v2_truncated'), new Date(time));
  assert.equal(frame('global_v2_truncated')[1], 12);
  assert.equal(value.position.lat, 1); assert.equal(value.position.lng, 2);
  assert.equal(value.position.horizontalAccuracyM, null);
  const [zero] = parseMavlinkDatagram(frame('global_v2_one_byte'), new Date(time));
  assert.equal(zero.position.lat, 0); assert.equal(zero.position.lng, 0);
  assert.equal(zero.position.coordinateQuality, 'unknown');
});
test('reference truncated GPS preserves unknown HDOP and boot clock without inventing measured time', () => {
  const [value] = parseMavlinkDatagram(frame('gps_v2_boot_truncated'), new Date(time));
  assert.equal(value.position.hdop, null);
  assert.equal(value.position.horizontalAccuracyM, null);
  assert.equal(value.sourceTime.raw, '123456');
  assert.equal(value.sourceTime.clockBasis, 'boot_relative_or_unknown');
  assert.equal(value.sourceTime.observedAt, null);
});
test('corrupt, unsupported and incomplete MAVLink frames do not yield positions', () => {
  const bad = frame('gps_v1_hdop'); bad[12] ^= 255;
  assert.deepEqual(parseMavlinkDatagram(bad), []);
  assert.deepEqual(parseMavlinkDatagram(Buffer.from([253, 20, 0, 0])), []);
  assert.equal(parseMavlinkDatagram(Buffer.concat([bad, frame('global_v2_truncated')])).length, 1);
});
test('ROS UNKNOWN/absent covariance never implies perfect position accuracy', () => {
  for (const overrides of [{}, { position_covariance_type: undefined }, { position_covariance_type: 2, position_covariance: [9, 0, 0] }]) {
    const value = parseRosbridgeMessage(ros(overrides), new Date(time));
    assert.equal(value.position.horizontalAccuracyM, null);
    assert.equal(value.position.eastSigmaM, null);
    assert.equal(value.position.covarianceEnuM2, null);
  }
});
test('ROS known covariance retains full ENU matrix and separate east/north uncertainty', () => {
  const matrix = [9, 1, 0, 1, 100, 0, 0, 0, 4];
  const value = parseRosbridgeMessage(ros({ position_covariance_type: 3, position_covariance: matrix }), new Date(time));
  assert.deepEqual(value.position.covarianceEnuM2, matrix);
  assert.equal(value.position.eastSigmaM, 3); assert.equal(value.position.northSigmaM, 10); assert.equal(value.position.upSigmaM, 2);
  assert.equal(value.position.horizontalAccuracyM, null);
  assert.equal(value.position.covarianceType, 3);
  for (const invalid of [[-1,0,0,0,1,0,0,0,1], [1,2,0,2,1,0,0,0,1]]) assert.equal(parseRosbridgeMessage(ros({ position_covariance_type: 3, position_covariance: invalid }), new Date(time)).position.covarianceEnuM2, null);
});
test('ROS declared wall clock and unknown/simulation clock preserve distinct source times', () => {
  const unknown = parseRosbridgeMessage(ros(), new Date(time));
  assert.equal(unknown.sourceTime.clockBasis, 'ros_clock_unknown'); assert.equal(unknown.sourceTime.observedAt, null);
  const unix = parseRosbridgeMessage(ros(), new Date(time), { rosClock: 'unix' });
  assert.equal(unix.sourceTime.observedAt, reference.referenceTime);
  assert.equal(unix.sourceTime.verified, false);
  assert.equal(parseRosbridgeMessage(ros({ header: { stamp: { sec: 0, nanosec: 0 } } }), new Date(time), { rosClock: 'unix' }).sourceTime.observedAt, null);
});
test('ROS requires reported fix status and geodetic coordinates; rejects other topics and malformed payloads', () => {
  for (const input of [{ status: { status: -1 } }, { status: {} }, { latitude: 91 }]) assert.equal(parseRosbridgeMessage(ros(input)).position, null);
  assert.equal(parseRosbridgeMessage(ros(), new Date(time), { topic: '/other' }), null);
  assert.equal(parseRosbridgeMessage('{oops'), null);
});
test('UDP is receive only, filters robot identity, and emits ignored packet/lifecycle states', () => {
  const listeners = new Map(), values = [], states = [];
  const socket = { on(n, f) { listeners.set(n, f); }, bind(p, host) { this.bound = { p, host }; }, close() { this.closed = true; } };
  const a = createMavlinkUdpAdapter({ systemId: 42, componentId: 17, socketFactory: () => socket, onTelemetry: t => values.push(t), onState: s => states.push(s) });
  listeners.get('listening')(); listeners.get('message')(Buffer.from([1,2])); listeners.get('message')(frame('gps_v1_hdop'));
  assert.equal(values.length, 1); assert.deepEqual(socket.bound, { p: 14550, host: '127.0.0.1' });
  assert.equal(states[1].reason, 'unsupported_or_invalid_frame');
  a.close(); a.close(); assert.equal(socket.closed, true);
});
test('rosbridge only subscribes, retries disconnect with bounded backoff, and cancels reconnect on close', () => {
  class Socket {
    static instances = [];
    constructor(url) { this.url = url; this.listeners = {}; this.sent = []; Socket.instances.push(this); }
    addEventListener(n, f) { this.listeners[n] = f; }
    send(value) { this.sent.push(JSON.parse(value)); }
    close() { this.listeners.close?.(); }
    emit(n, value) { this.listeners[n]?.(value); }
  }
  const jobs = [], states = [], values = [];
  const a = createRosbridgeAdapter({ rosbridgeUrl: 'ws://127.0.0.1:9090', onTelemetry: t => values.push(t), onState: s => states.push(s), WebSocketImpl: Socket, setTimeoutFn: (f, ms) => { const j = { f, ms }; jobs.push(j); return j; }, clearTimeoutFn: j => { j.cancelled = true; } });
  const first = Socket.instances[0]; first.emit('open'); first.emit('message', { data: ros() });
  assert.deepEqual(first.sent, [{ op: 'subscribe', topic: '/fix', type: 'sensor_msgs/msg/NavSatFix', throttle_rate: 1000, queue_length: 1 }]);
  assert.equal(values.length, 1);
  first.emit('close'); assert.equal(jobs[0].ms, 1000); jobs[0].f();
  Socket.instances[1].emit('close'); assert.equal(jobs[1].ms, 2000);
  a.close(); assert.equal(jobs[1].cancelled, true);
  assert.ok(states.some(s => s.status === 'disconnected'));
  assert.throws(() => createRosbridgeAdapter({ rosbridgeUrl: 'ws://remote.example', onTelemetry() {} }), /wss/);
  assert.throws(() => createRosbridgeAdapter({ rosbridgeUrl: 'wss://remote.example?secret=1', onTelemetry() {} }), /without credentials/);
});
test('environment lookup uses bearer-auth GET, preserves evidence and unknowns, and defaults to 120-second cadence', async () => {
  let clock = time;
  const requests = [];
  const client = createSenlayClient({ baseUrl: 'https://senlay.example', apiKey: 'fixture-key', fetchImpl: async (url, options) => { requests.push({ url, options }); return { ok: true, json: async () => ({ status: 'ok', unknowns: ['no local observation'], risk_assessment: { outcome: 'INSUFFICIENT_EVIDENCE' } }) }; } });
  const a = createRoboticsContextAdapter({ client, now: () => clock });
  const r = await a.handleTelemetry(telemetry());
  assert.equal(r.status, 'context'); assert.equal(r.safetyClearance, 'not_provided'); assert.equal(r.environment.unknowns[0], 'no local observation');
  assert.equal(r.telemetry.measurementFreshness.status, 'unknown');
  assert.equal(requests[0].options.method, 'GET'); assert.equal(requests[0].options.headers.Authorization, 'Bearer fixture-key');
  assert.equal(requests[0].url.searchParams.get('view'), 'full'); assert.equal(requests[0].url.toString().includes('fixture-key'), false);
  clock += 119_999; assert.equal((await a.handleTelemetry(telemetry(clock))).reason, 'request_interval');
  clock += 1; assert.equal((await a.handleTelemetry(telemetry(clock))).status, 'context');
  assert.equal(DEFAULT_ENVIRONMENT_INTERVAL_MS, 120_000);
});
test('invalid/stale/future receipts and declared old measurements skip without API spending', async () => {
  let calls = 0;
  const a = createRoboticsContextAdapter({ client: { getPWM: async () => { calls++; return {}; } }, now: () => time });
  assert.equal((await a.handleTelemetry(telemetry(time - 15_001))).reason, 'stale_telemetry');
  assert.equal((await a.handleTelemetry(telemetry(time + 1))).reason, 'invalid_or_future_receive_time');
  const old = parseRosbridgeMessage(ros({ header: { stamp: { sec: time / 1000 - 60, nanosec: 0 } } }), new Date(time), { rosClock: 'unix' });
  assert.equal((await a.handleTelemetry(old)).reason, 'stale_or_future_measurement');
  assert.equal((await a.handleTelemetry({ ...telemetry(), position: null })).reason, 'valid_position_unavailable'); assert.equal(calls, 0);
});
test('completion freshness includes HTTP time and labels expired responses stale', async () => {
  let clock = time;
  const a = createRoboticsContextAdapter({ client: { getPWM: async () => { clock += 16_000; return { response: { status: 'ok' } }; } }, now: () => clock });
  const r = await a.handleTelemetry(telemetry());
  assert.equal(r.status, 'stale_context'); assert.equal(r.elapsedMs, 16_000); assert.equal(r.telemetry.receiveFreshness.ageMs, 16_000); assert.equal(r.telemetry.receiveFreshness.status, 'stale');
});
test('single in-flight lookup prevents out-of-order overwrites and snapshots position identity', async () => {
  let resolve, calls = 0;
  const a = createRoboticsContextAdapter({ client: { getPWM: () => { calls++; return new Promise(r => { resolve = r; }); } }, now: () => time, minRequestIntervalMs: 0 });
  const input = telemetry(), first = a.handleTelemetry(input); input.position.lat = 40;
  assert.equal((await a.handleTelemetry(telemetry())).reason, 'lookup_in_flight');
  resolve({ response: { status: 'ok' } }); const r = await first;
  assert.equal(r.telemetry.position.lat, 1); assert.equal(calls, 1); assert.equal(a.getState().inFlight, false);
});
test('API failures produce visible sanitized state and honor Retry-After with bounded backoff', async () => {
  let clock = time, calls = 0;
  const a = createRoboticsContextAdapter({ client: { getPWM: async () => { calls++; const e = new Error('private secret'); e.status = 429; e.retryAfterMs = 600_000; throw e; } }, now: () => clock });
  const first = await a.handleTelemetry(telemetry()); assert.equal(first.status, 'request_error'); assert.equal(first.httpStatus, 429); assert.equal(first.retryAfterMs, 600_000); assert.equal(JSON.stringify(first).includes('private secret'), false);
  clock += 120_000; assert.equal((await a.handleTelemetry(telemetry(clock))).reason, 'request_backoff'); assert.equal(calls, 1);
});

test('signed MAVLink 2 frames retain explicit unverified signature state', () => {
  // Add signing flag/signature to independently C-generated bytes; CRC covers changed header.
  const original = frame('gps_v2_hacc'), packet = Buffer.concat([original, Buffer.alloc(13)]);
  packet[2] = 1;
  let crc = 65535;
  function acc(c, b) { let t = b ^ (c & 255); t ^= t << 4 & 255; return ((c >> 8) ^ (t << 8) ^ (t << 3) ^ (t >> 4)) & 65535; }
  for (let i = 1; i < original.length - 2; i++) crc = acc(crc, packet[i]);
  packet.writeUInt16LE(acc(crc, 24), original.length - 2);
  const [value] = parseMavlinkDatagram(packet, new Date(time));
  assert.equal(value.sourceIdentity.signaturePresent, true);
  assert.equal(value.sourceIdentity.authenticated, false);
  assert.equal(value.position.horizontalAccuracyM, 4);
});

test('robotics drone profile is wind, other domains remain full, and explicit override is preserved', async () => {
  const calls = [];
  const client = { getPWM: async options => { calls.push(options); return { response: { status: 'ok' } }; } };
  for (const options of [{}, { field: 'sailing' }, { profile: 'full' }]) await createRoboticsContextAdapter({ client, now: () => time, ...options }).handleTelemetry(telemetry());
  assert.deepEqual(calls.map(c => c.profile), ['wind', 'full', 'full']);
  assert.throws(() => createRoboticsContextAdapter({ client, profile: 'invalid' }), /profile/);
});
