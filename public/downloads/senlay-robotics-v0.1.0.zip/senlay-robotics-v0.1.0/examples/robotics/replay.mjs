import { createSenlayClient } from '../../sdk/client.mjs';
import { createRoboticsContextAdapter, parseRosbridgeMessage } from '../../sdk/robotics-adapters.mjs';

/** Deterministic synthetic demonstration. It performs zero network requests. */
export async function runSyntheticReplay({ emit = value => console.log(JSON.stringify(value)) } = {}) {
  let clock = Date.parse('2026-10-31T12:00:00.000Z');
  let failNext = false;
  const environment = {
    status: 'ok', demo_mode: 'synthetic_fixture', observed_at: new Date(clock).toISOString(),
    coordinates: { lat: 37.775, lng: -122.419 },
    observations: [{ phenomenon: 'wind.speed', value: 5, unit: 'm/s', source: 'synthetic_fixture', evidence_type: 'synthetic', observed_at: new Date(clock).toISOString() }],
    confidence: 'unknown', unknowns: ['Synthetic fixture: no current weather or hardware measurement.', 'Aircraft-specific limits and mission route are not evaluated.'],
    risk_assessment: { outcome: 'INSUFFICIENT_EVIDENCE', is_safety_clearance: false }
  };
  const client = createSenlayClient({ baseUrl: 'https://synthetic.invalid', apiKey: 'synthetic-fixture-key-never-sent', fetchImpl: async () => {
    if (failNext) return { ok: false, status: 429, headers: new Headers({ 'retry-after': '120' }) };
    clock += 250;
    return { ok: true, status: 200, json: async () => structuredClone(environment) };
  } });
  const adapter = createRoboticsContextAdapter({ client, now: () => clock });
  function telemetry({ measurementOffsetMs = 0, fixStatus = 0 } = {}) {
    const sourceTime = clock + measurementOffsetMs;
    const parsed = parseRosbridgeMessage(JSON.stringify({ op: 'publish', topic: '/fix', msg: {
      header: { stamp: { sec: Math.floor(sourceTime / 1000), nanosec: sourceTime % 1000 * 1e6 }, frame_id: 'synthetic_gps' },
      status: { status: fixStatus }, latitude: 37.775, longitude: -122.419,
      position_covariance_type: 0, position_covariance: Array(9).fill(0)
    } }), new Date(clock), { rosClock: 'unix' });
    return { ...parsed, mode: 'synthetic_replay' };
  }
  emit({ status: 'replay_started', mode: 'synthetic_replay', network: 'disabled_injected_fetch', note: 'Both telemetry and environmental evidence are synthetic. No robot or provider is contacted.' });
  for (const input of [telemetry(), telemetry(), telemetry({ fixStatus: -1 }), telemetry({ measurementOffsetMs: -60_000 })]) emit(await adapter.handleTelemetry(input));
  clock += 120_001; failNext = true;
  emit(await adapter.handleTelemetry(telemetry()));
  emit(await adapter.handleTelemetry(telemetry()));
  emit({ status: 'replay_complete', mode: 'synthetic_replay', safetyClearance: 'not_provided' });
}
