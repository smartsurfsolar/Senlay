#!/usr/bin/env node
import { createSenlayClient } from '../../sdk/client.mjs';
import { createMavlinkUdpAdapter, createRosbridgeAdapter, createRoboticsContextAdapter } from '../../sdk/robotics-adapters.mjs';
import { runSyntheticReplay } from './replay.mjs';

function parseArgs(argv) {
  const options = { transport: 'replay', host: '127.0.0.1', port: 14550, field: 'drone', topic: '/fix', requestIntervalSeconds: 120, rosClock: 'unknown' };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i], name = arg.slice(2);
    if (arg === '--help') { options.help = true; continue; }
    if (!arg.startsWith('--') || !argv[i + 1] || argv[i + 1].startsWith('--')) throw new TypeError('Each option requires a value; use --help.');
    const value = argv[++i];
    const names = { 'rosbridge-url': 'rosbridgeUrl', 'ros-clock': 'rosClock', 'system-id': 'systemId', 'component-id': 'componentId', 'request-interval-seconds': 'requestIntervalSeconds' };
    const key = names[name] || name;
    if (!['transport', 'host', 'port', 'field', 'topic', 'profile', ...Object.values(names)].includes(key)) throw new TypeError('Unknown option; use --help.');
    options[key] = ['port', 'systemId', 'componentId', 'requestIntervalSeconds'].includes(key) ? Number(value) : value;
  }
  if (!['replay', 'mavlink-udp', 'rosbridge'].includes(options.transport)) throw new TypeError('--transport must be replay, mavlink-udp, or rosbridge.');
  if (!Number.isFinite(options.requestIntervalSeconds) || options.requestIntervalSeconds < 120) throw new TypeError('--request-interval-seconds must be at least 120.');
  if (!['unknown', 'unix'].includes(options.rosClock)) throw new TypeError('--ros-clock must be unknown or unix.');
  options.profile ??= options.field === 'drone' ? 'wind' : 'full';
  if (!['wind', 'full'].includes(options.profile)) throw new TypeError('--profile must be wind or full.');
  return options;
}
function usage() {
  return [
    'Senlay read-only robotics example (Node.js 22, no npm install)',
    'Offline, explicitly synthetic telemetry AND evidence; no key or network:',
    '  node examples/robotics/robotics-context.mjs --transport replay',
    'Receive MAVLink telemetry from your trusted network:',
    '  --transport mavlink-udp --host 127.0.0.1 --port 14550 --system-id 1 --field drone',
    'ROS 2 NavSatFix through separately installed rosbridge:',
    '  --transport rosbridge --rosbridge-url ws://127.0.0.1:9090 --topic /fix --ros-clock unknown',
    '  --ros-clock unix only when the publisher uses a correctly synchronized Unix clock.',
    'Environmental request interval defaults to 120 seconds (30/hour); use --request-interval-seconds >=120.',
    'Drone field defaults to --profile wind (atmospheric wind sources); other fields use full. Override explicitly if needed.',
    'Free account allowance is normally 100 authenticated calls/day shared with other API use; check dashboard.',
    'Live environment: SENLAY_API_KEY required; SENLAY_API_BASE_URL optional (default https://senlay.cloud).',
    'No robot commands or safety clearance. Receipt freshness and source measurement time are separate.'
  ].join('\n');
}
async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) { console.log(usage()); return; }
  if (options.transport === 'replay') { await runSyntheticReplay(); return; }
  if (!process.env.SENLAY_API_KEY?.trim()) throw new TypeError('Set SENLAY_API_KEY in the environment.');
  const output = value => console.log(JSON.stringify({ mode: 'live_telemetry', ...value }));
  const client = createSenlayClient({ baseUrl: process.env.SENLAY_API_BASE_URL || 'https://senlay.cloud', apiKey: process.env.SENLAY_API_KEY });
  const adapter = createRoboticsContextAdapter({ client, field: options.field, profile: options.profile, minRequestIntervalMs: options.requestIntervalSeconds * 1000, onState: value => { if (value.status === 'lookup_started') output(value); } });
  let lastReceivedAt = null, lastLabel = null, lastLog = 0, stopped = false;
  function state(value) {
    const label = `${value.status}:${value.reason || ''}`;
    if (label !== lastLabel || Date.now() - lastLog > 30_000) { output(value); lastLabel = label; lastLog = Date.now(); }
  }
  const onTelemetry = async telemetry => {
    lastReceivedAt = Date.now();
    const result = await adapter.handleTelemetry(telemetry);
    if (!stopped) result.status === 'skipped' ? state(result) : output(result);
  };
  const onError = () => state({ status: 'transport_error', message: 'Check telemetry connection and trusted network configuration.' });
  const listener = options.transport === 'mavlink-udp'
    ? createMavlinkUdpAdapter({ bindAddress: options.host, port: options.port, systemId: options.systemId, componentId: options.componentId, onTelemetry, onError, onState: state })
    : createRosbridgeAdapter({ rosbridgeUrl: options.rosbridgeUrl, topic: options.topic, rosClock: options.rosClock, onTelemetry, onError, onState: state });
  state({ status: 'waiting_for_telemetry', requestIntervalSeconds: options.requestIntervalSeconds, accountAllowance: 'Normally 100 authenticated calls/day on free tier; shared account usage applies.', safetyClearance: 'not_provided' });
  const monitor = setInterval(() => {
    if (lastReceivedAt === null) state({ status: 'waiting_for_telemetry' });
    else if (Date.now() - lastReceivedAt > 15_000) state({ status: 'stale_telemetry', receiveAgeMs: Date.now() - lastReceivedAt });
  }, 5000);
  function stop() { stopped = true; clearInterval(monitor); listener.close(); }
  process.once('SIGINT', stop); process.once('SIGTERM', stop);
}
main().catch(error => { console.error(JSON.stringify({ status: 'startup_error', message: error?.message || 'Robotics example could not start.' })); process.exitCode = 1; });
