# Senlay read-only robotics example · 0.1.0

Use a robot's geodetic position to request spot-level environmental evidence
from Senlay. This is an operator/developer example. It does not control a robot,
evaluate a route, simulate a mission, or issue safety clearance. Hardware and
field validation remain separate pilot work.

## Try the entire flow offline

Download `https://senlay.cloud/downloads/senlay-robotics-v0.1.0.zip`, then:

```bash
unzip senlay-robotics-v0.1.0.zip
cd senlay-robotics-v0.1.0
node examples/robotics/robotics-context.mjs --transport replay
```

Requires Node.js 22. No `npm install`, API key, ROS installation, robot, or
network access is used in replay. Both telemetry and environmental evidence
are explicitly **synthetic** with fixed fixture timestamps. Newline-delimited
JSON shows context, rate-limit skips, no fix, old measurements, a simulated
HTTP 429, backoff, and completion. This is a software integration demonstration,
not live weather or a hardware test.

```bash
node test/robotics-adapters.test.mjs
node examples/robotics/robotics-context.mjs --help
```

The archive's `SOURCE-MANIFEST.json` lists every file hash and an aggregate source
identity. The adjacent `.manifest.json` and `.sha256` downloads identify the ZIP.
No private backend, dependencies, credentials, or customer data are included.
The MIT grant in `LICENSE` applies only to this enumerated example bundle.

## Use real telemetry and your Senlay API key

Create a key in `https://senlay.cloud/register.html`. Set `SENLAY_API_KEY` in the
environment using your secret manager or shell's silent prompt; do not place it
in URLs, source, or a command argument. Optionally set `SENLAY_API_BASE_URL`
(default `https://senlay.cloud`). HTTPS is required except loopback development.

```bash
read -rs SENLAY_API_KEY
export SENLAY_API_KEY
node examples/robotics/robotics-context.mjs \
  --transport mavlink-udp --host 127.0.0.1 --port 14550 --system-id 1 --field drone
```

MAVLink UDP is receive only. Configure your autopilot or telemetry router to send
common MAVLink 1/2 `GPS_RAW_INT` or `GLOBAL_POSITION_INT` frames to that interface.
There is no automatic message-rate command, heartbeat, flight command, serial
connection, or native PX4/ArduPilot/BlueOS plugin. For another device, bind the
specific trusted robot-network IP with `--host`; avoid exposing it publicly.
`--system-id` and optional `--component-id` select the intended sender. Identity
fields and CRC do not authenticate it, and MAVLink signatures are not verified.

For ROS 2, separately install and run ROS 2 and `rosbridge_server`, publishing a
`sensor_msgs/msg/NavSatFix` topic with latitude/longitude and fix status:

```bash
node examples/robotics/robotics-context.mjs \
  --transport rosbridge --rosbridge-url ws://127.0.0.1:9090 \
  --topic /gps/fix --ros-clock unknown --field agriculture
```

Remote rosbridge requires `wss://`. The adapter sends only a subscription and
reconnects after disconnect with bounded 1–30 second backoff. Network/ROS access
controls are your responsibility. Local `Odometry`/`PoseStamped` positions are
not converted. `--ros-clock unix` is an explicit operator declaration that the
publisher's clock is correctly synchronized Unix time; simulation time and
unmapped ROS clocks must use `unknown`.

## Capacity, quota, and visible states

Environmental requests default to **120 seconds minimum (at most 30/hour per
adapter)**. This is slow environmental context polling, not a robot control loop.
Live CLI intervals can be increased with `--request-interval-seconds 300` and
cannot be lowered below 120. The small MVP capacity plan supports two supervised
pilots at 30 refreshes/hour each plus a bounded browser demo. Confirm the actual
pilot allowance before unattended use.

A free account normally has **100 authenticated API calls/day shared across its
keys and API use**; at 30/hour that is at most about 3 hours 20 minutes with no
other calls. Your dashboard/tier governs the actual allowance. A 120-second
cadence is not permission for continuous free operation. Stop the listener when
you finish. HTTP 429 and other errors are visible and use bounded exponential
backoff, respecting supported `Retry-After` values. There is one in-flight
lookup, so a slower earlier result cannot overwrite a later completed lookup.

Stdout is JSON with `waiting_for_telemetry`, transport lifecycle events,
`lookup_started`, `context`, `stale_context`, `skipped` reasons, `request_error`,
and stale/disconnected states. Repeated skip/wait messages are summarized at
most every 30 seconds. Senlay's returned evidence, uncertainty, risk fields,
and unknown extensions are preserved. Inspect environmental source timestamps
and coverage separately from robot telemetry.

## Units and time contract

- MAVLink EPH is HDOP/100, **dimensionless**, exposed as `position.hdop`.
  `horizontalAccuracyM` uses positive MAVLink 2 `h_acc` millimetres/1000 only;
  absent/zero accuracy stays unknown. Truncated MAVLink 2 base fields are decoded
  with zero extension after CRC checking.
- ROS UNKNOWN/absent/invalid covariance stays unknown. Known valid ENU covariance
  is preserved as `covarianceEnuM2` with named east/north/up sigma values in metres;
  no general horizontal accuracy is inferred from just the east variance.
- `sourceTime` retains raw source time and clock basis. Boot-relative MAVLink and
  undeclared ROS clocks have unknown measurement time. Reported Unix times are
  **not authenticated** and require a synchronized source clock.
- `receiveFreshness` is time since local message receipt, recomputed after the
  HTTP request. `measurementFreshness` is separate; its unknown value never means
  a fresh measurement. Known old/future positions are skipped; a position that
  expires during lookup yields `stale_context`, not a current-position result.

Review [MAVLink GPS_RAW_INT](https://mavlink.io/en/messages/common.html#GPS_RAW_INT),
[MAVLink 2 truncation](https://mavlink.io/en/guide/serialization.html#empty-byte-payload-truncation-mavlink-2),
and [ROS NavSatFix](https://github.com/ros2/common_interfaces/blob/rolling/sensor_msgs/msg/NavSatFix.msg).
The frozen reference packet fixtures were generated with the actual upstream
MAVLink C serializer pinned in `sdk/fixtures/mavlink-reference.json`; the original
headers are not distributed. `sdk/fixtures/README.md` explains reproduction.

Drone examples request `profile=wind` by default to collect only the supported
atmospheric wind sources and avoid unnecessary marine/terrain/air-quality
fan-out. Other fields default to `profile=full`. Set `--profile wind` or
`--profile full` explicitly when the use case requires it. Wind profile does not
supply visibility, precipitation, altitude wind, aircraft limits or flight
permission. SDK callers may omit `profile` to preserve the server's existing
full default; only explicit `wind`/`full` profile values are accepted.
